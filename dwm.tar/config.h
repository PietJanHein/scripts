 /* See LICENSE file for copyright and license details. */

/* appearance */
static const unsigned int borderpx  = 0;        /* border pixel of windows */
static const unsigned int snap      = 32;       /* snap pixel */
static const unsigned int minwsz    = 20;       /* Minimal heigt of a client for smfact */
static const unsigned int systraypinning = 0;   /* 0: sloppy systray follows selected monitor, >0: pin systray to monitor X */
static const unsigned int systrayonleft = 0;   	/* 0: systray in the right corner, >0: systray on left of status text */
static const unsigned int systrayspacing = 2;   /* systray spacing */
static const int systraypinningfailfirst = 1;   /* 1: if pinning fails, display systray on the first monitor, False: display systray on the last monitor*/
static const int showsystray        = 1;     /* 0 means no systray */
static const int showbar            = 0;     /* 0 means no bar */
static const int topbar             = 1;     /* 0 means bottom bar */
static const char *fonts[]          = { "jetbrains:size=20" };
static const char dmenufont[]       = "jetbrains:size=20";
static const char col_gray1[]       = "#222222";
static const char col_gray2[]       = "#444444";
static const char col_gray3[]       = "#bbbbbb";
static const char col_gray4[]       = "#eeeeee";
//static const char col_cyan[]        = "#762487";
static const char col_cyan[]        = "#70327e";
//static const char col_cyan[]        = "#0b6a88";
//static const char col_cyan[]        = "#2dc5f4";
//static const char col_cyan[]        = "#9253a1";
//static const char col_cyan[]        = "#a42963";
//static const char col_cyan[]        = "#f063a4";
//static const char col_cyan[]        = "#f89e4f";
//static const char col_cyan[]        = "#f16164";
//static const char col_cyan[]        = "#fcee21";
static const char *colors[][3]      = {
	/*               fg         bg         border   */
	[SchemeNorm] = { col_gray3, col_gray1, col_gray2 },
	[SchemeSel]  = { col_gray4, col_cyan,  col_cyan  },
};

/* tagging */
static const char *tags[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

static const Rule rules[] = {
	/* xprop(1):
	 *	WM_CLASS(STRING) = instance, class
	 *	WM_NAME(STRING) = title
	 */
	/* class      instance    title       tags mask     isfloating   monitor */
	{ "Gimp",     NULL,       NULL,       0,            1,           -1 },
	{ "Firefox",  NULL,       NULL,       1 << 8,       0,           -1 },
	{ "Steam",    "Steam",    "Steam",    1 << 6,	    0,           -1 },
	{ "Lutris",   NULL,   	  NULL,       1 << 7,	    0,           -1 },
	{ "Kotatogram", NULL,	  NULL,       1 << 2,       0,           -1 },
	{ "Deadbeef", NULL,	  NULL,       1 << 8,       0,           -1 },
};

/* layout(s) */
static const float mfact     = 0.5; /* factor of master area size [0.05..0.95] */
static const float smfact     = 0.00; /* factor of tiled clients [0.00..0.95] */
static const int nmaster     = 1;    /* number of clients in master area */
static const int resizehints = 1;    /* 1 means respect size hints in tiled resizals */
static const int lockfullscreen = 1; /* 1 will force focus on the fullscreen window */

#include "horizgrid.c"
#include "tatami.c"

static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "[]=",      tile },    /* first entry is default */
	{ "><>",      NULL },    /* no layout function means floating behavior */
	{ "[M]",      monocle },
	{ "###",      horizgrid },
	{ "|+|",     tatami },
};

/* key definitions */
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} }, \
	{ Mod1Mask|ControlMask,         KEY,      toggleview,      {.ui = 1 << TAG} }, 

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define CMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands */
static char dmenumon[2] = "0"; /* component of dmenucmd, manipulated in spawn() */
static const char *dmenucmd[] = { "dmenu_run", "-m", dmenumon, "-fn", dmenufont, "-nb", col_gray1, "-nf", col_gray3, "-sb", col_cyan, "-sf", col_gray4, NULL };
static const char *termcmd[]  = { "alacritty", NULL };

static Key keys[] = {
	/* modifier                     key        function        argument */
	{ ControlMask|ShiftMask,        XK_d,      spawn,          {.v = dmenucmd } },
	{ MODKEY,             		XK_Return, spawn,          {.v = termcmd } },
	{ MODKEY,                       XK_b,      togglebar,      {0} },
	{ MODKEY|ShiftMask,             XK_k,      rotatestack,    {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_j,      rotatestack,    {.i = -1 } },
	{ MODKEY,                       XK_k,      focusstack,     {.i = +1 } },
	{ MODKEY,                       XK_j,      focusstack,     {.i = -1 } },
	{ MODKEY,                       XK_i,      incnmaster,     {.i = +1 } },
	{ MODKEY,                       XK_d,      incnmaster,     {.i = -1 } },
	{ MODKEY,                       XK_h,      setmfact,       {.f = -0.05} },
	{ MODKEY,                       XK_l,      setmfact,       {.f = +0.05} },
	{ MODKEY|ShiftMask,             XK_u,      setsmfact,      {.f = +0.05} },
	{ MODKEY|ShiftMask,             XK_o,      setsmfact,      {.f = -0.05} },
	{ MODKEY|ShiftMask,             XK_Return, zoom,           {0} },
	{ MODKEY,                       XK_Tab,    view,           {0} },
	{ MODKEY|ShiftMask,             XK_c,      killclient,     {0} },
	{ MODKEY,                       XK_t,      setlayout,      {.v = &layouts[0]} },
	{ MODKEY,                       XK_f,      setlayout,      {.v = &layouts[1]} },
	{ MODKEY,                       XK_m,      setlayout,      {.v = &layouts[2]} },
	{ MODKEY|ShiftMask, 		XK_h,	   setlayout,	   {.v = &layouts[3]} },
	{ ControlMask|ShiftMask|Mod1Mask,	XK_p,	   setlayout,	   {.v = &layouts[4]} },
	{ MODKEY,                       XK_space,  setlayout,      {0} },
	{ MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
	{ MODKEY,                       XK_0,      view,           {.ui = ~0 } },
	{ MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } },
	{ MODKEY,                       XK_comma,  focusmon,       {.i = -1 } },
	{ MODKEY,                       XK_period, focusmon,       {.i = +1 } },
	{ MODKEY|ShiftMask,             XK_comma,  tagmon,         {.i = -1 } },
	{ MODKEY|ShiftMask,             XK_period, tagmon,         {.i = +1 } },

	{ Mod1Mask|ControlMask, XK_f,      spawn,          CMD("pcmanfm") },
        { Mod1Mask|ControlMask|ShiftMask, XK_f,      spawn,          CMD("firefox") },
        { Mod1Mask|ControlMask|ShiftMask, XK_t,      spawn,          CMD("kotatogram-desktop") },
        { Mod1Mask|ControlMask,                   XK_t,      spawn,              CMD("thunderbird") },
        { Mod1Mask|ControlMask,                   XK_n,      spawn,              CMD("notepadqq") },
        { Mod1Mask|ControlMask,                   XK_q,      spawn,              CMD("qpdfview") },
        { Mod1Mask|ControlMask,                   XK_c,      spawn,              CMD("chromium") },
        { ControlMask|Mod1Mask,                   XK_b,      spawn,              CMD("brave") },
        { Mod1Mask|ControlMask,         0xff52,      spawn,          CMD("amixer -D pulse set Master 3%+") },
        { Mod1Mask|ControlMask,         0xff54,      spawn,          CMD("amixer -D pulse set Master 3%-") },
        { Mod1Mask|ControlMask|ShiftMask, 0xffff,      spawn,          CMD("systemctl suspend") },
        { Mod1Mask|ControlMask|ShiftMask, 0xff56,      spawn,          CMD("shutdown now")},
        { Mod1Mask|ControlMask|ShiftMask, 0xff50,      spawn,          CMD("reboot") },
	{ ControlMask|ShiftMask, XK_f,                 spawn, 	       CMD("/home/peter/Scripts/bing") },
        {ControlMask|ShiftMask, XK_l,                  spawn,          CMD("lutris") },
        {ControlMask|Mod1Mask, XK_d,                    spawn,         CMD("deadbeef")},
        {MODKEY, XK_p,                  spawn,          CMD("flameshot screen -n 0 -c")},
        {MODKEY|ShiftMask, XK_p,        spawn,          CMD("flameshot screen -n 1 -c")},
        {MODKEY, XK_o,                  spawn,          CMD("flameshot screen -n 0 -c -p ~/Pictures")},
        {MODKEY|ShiftMask, XK_o,        spawn,          CMD("flameshot screen -n 1 -c -p ~/Pictures")},
        {MODKEY, XK_c,  		spawn,  	CMD("gnome-calculator")},
        {ControlMask|ShiftMask, XK_b,   spawn,          CMD("mpv ~/Videos/wimhof.m4v")},
        {ControlMask|Mod1Mask,  XK_s,   spawn,          CMD("steam")},
        {ControlMask|Mod1Mask|ShiftMask, XK_l, spawn,   CMD("libreoffice")},
        {ControlMask|Mod1Mask|ShiftMask, XK_k, spawn,  CMD("firefox --private-window https://knmi.nl/nederland-nu/weer/waarnemingen")},
	{ControlMask|Mod1Mask|ShiftMask, XK_p, spawn,   CMD("alacritty -e vim ~/code/voorbeeld_array.c")},
	{ControlMask|Mod1Mask|ShiftMask, XK_m, spawn,   CMD("pactl set-source-mute alsa_input.usb-MICE_MICROPHONE_USB_MICROPHONE_201308-00.mono-fallback 1")},
	{ControlMask|Mod1Mask|ShiftMask, XK_u, spawn,   CMD("pactl set-source-mute alsa_input.usb-MICE_MICROPHONE_USB_MICROPHONE_201308-00.mono-fallback 0")},

	TAGKEYS(                  0xff9c,          0)
        TAGKEYS(                  0xff99,          1)
        TAGKEYS(                  0xff9b,          2)
        TAGKEYS(                  0xff96,          3)
        TAGKEYS(                  0xff9d,          4)
        TAGKEYS(                  0xff98,          5)
        TAGKEYS(                  0xff95,          6)
        TAGKEYS(                  0xff97,          7)
        TAGKEYS(                  0xff9a,          8)
	{ MODKEY|ShiftMask,             XK_q,      quit,           {0} },
};

/* button definitions */
/* click can be ClkTagBar, ClkLtSymbol, ClkStatusText, ClkWinTitle, ClkClientWin, or ClkRootWin */
static Button buttons[] = {
	/* click                event mask      button          function        argument */
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
	{ ClkWinTitle,          0,              Button2,        zoom,           {0} },
	{ ClkStatusText,        0,              Button2,        spawn,          {.v = termcmd } },
	{ ClkClientWin,         MODKEY,         Button1,        movemouse,      {0} },
	{ ClkClientWin,         MODKEY,         Button2,        togglefloating, {0} },
	{ ClkClientWin,         MODKEY,         Button3,        resizemouse,    {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
	{ ClkTagBar,            0,              Button3,        toggleview,     {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
};

